Example of custom event

https://developer.mozilla.org/en-US/docs/Web/Guide/Events/Creating_and_triggering_events