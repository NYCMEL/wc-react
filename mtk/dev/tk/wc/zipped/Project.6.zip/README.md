# WebComponents Demo

* Example of using another ui library (jquery ui) inside a web component and passing callback functions for interaction