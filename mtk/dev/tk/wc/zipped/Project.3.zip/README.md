# WebComponents Demo

* Shows how to expose API methods (startPB) from a Web Component and invoke it from application code

* Shows how to expose properties (max)from a Web Component and get /set it from application code

